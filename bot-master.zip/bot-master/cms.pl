#!/usr/bin/perl
use IO::Select;
use Parallel::ForkManager;
use HTTP::Response;
use URI::URL;
use IO::Socket::INET;
use Term::ANSIColor qw(:constants);
use LWP;
use HTTP::Cookies;
use HTML::Entities;
use URI::Escape;
#use Win32::Console::ANSI;
use HTTP::Request;
use HTTP::Request::Common qw(POST);
use LWP::UserAgent;
use Term::ANSIColor;
use MIME::Base64;
use WWW::Mechanize;
use threads;
print "[+]List :";
my $list = <STDIN>;
open (THETARGET, "<$list") || die "[-] Can't open the list websites file";
@TARGETS = <THETARGET>;
close THETARGET;
$link=$#TARGETS + 1;

print color("bold white"), "[+] Total sites : ";
print color("bold red"), "".scalar(@TARGETS)."\n\n\n";
print color('reset');

my $pm = new Parallel::ForkManager(15);# preparing fork
OUTER: foreach $site(@TARGETS){#loop => working
my $pid = $pm->start and next;
chomp($site);
$a++;
scan();
    $pm->finish;
}
$pm->wait_all_children();


#open(sites,"<".$file) or die $!;
#while($site = <sites>)
#{
#chomp($site);
#$site = cleanurl($site);
#push(@threads, threads->create (\&scan, $site));
#sleep(1) while(scalar threads->list(threads::running) >= $thr);
#}
#eval {
#$_->join foreach @threads;
#@threads = ();
#};



close(sites);
sub scan {
$ua = LWP::UserAgent->new(keep_alive => 1);
$ua->agent("Mozilla/5.0 (X11; U; Linux i686; en-US; rv:0.9.3) Gecko/20010801");
$ua->timeout (20);

$magsite = $site . '/admin';

my $spyxy = $ua->get("http://".$site."/")->content;

if($spyxy =~/wp-content|wordpress|xmlrpc.php/) {

print color('bold green');
print "[wordpress] ==> http://".$site."\n";

open(save, '>>ep.txt');
print save "http://".$site."\n";
close(save);
print color('reset');

}
elsif ($spyxy =~/Drupal|drupal|sites\/all|drupal.org/){
print color('bold green');
print "[Drupal] ==> http://".$site."\n";

open(save, '>>ep.txt');
print save "http://".$site."\n";
close(save);
print color('reset');

} elsif ($spyxy =~/Prestashop|prestashop/){
print color('bold green');
print "[Prestashop] ==> http://".$site."\n";

open(save, '>>ep.txt');
print save "http://".$site."/\n";
close(save);
print color('reset');

}elsif ($spyxy =~/Log into Magento Admin Page|name=\"dummy\" id=\"dummy\"|Magento/){
print color('bold green');
print "[Magnto] ==> http://".$site."\n";

open(save, '>>ep.txt');
print save "http://".$site."\n";
close(save);
print color('reset');

}
elsif ($spyxy =~/route=product|OpenCart|route=common|catalog\/view\/theme/){
print color('bold green');
print "[Magnto] ==> http://".$site."\n";

open(save, '>>ep.txt');
print save "http://".$site."\n";
close(save);
print color('reset');

}
else{
print color('bold red');
print "[Not Found Cms] http://".$site."/ \n";
print color('reset');

}
}
sub cleanurl {
$site =~ /http[s]?:\/\/[www\.]{3}?[\.]?/g ? $site =~ s/http[s]?:\/\/[www\.]{3}?[\.]?//g : "";
$site =~ /http[s]?:\/\//g ? $site =~ s/http[s]?:\/\///g : "";
$site =~ /[\/]$/m ? $site =~ s/[\/]$// : "";
return $site;
}