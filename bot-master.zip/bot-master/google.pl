use HTTP::Response;
use URI::URL;
use LWP::UserAgent;
use Term::ANSIColor;
use HTTP::Request::Common qw(GET);
$ag = LWP::UserAgent->new();


print color 'reset';
print color("bold Green"), "\n";
print color 'reset';
print color 'reset';
print color("bold red"), "                      {*} Grab Site From Google By Dork {*}               \n";
print color 'reset';
print color("bold Green"), "\n";

$ag = LWP::UserAgent->new();
$ag->agent("Mozilla/5.0 (X11; U; Linux i686; en-US; rv:0.9.3) Gecko/20010801");
$ag->timeout(10);


print color("bold Green"),"Dork: ";
$dork=<STDIN>;
chomp $dork;
print color("yellow"), "\n";


for (my $i=1; $i<=2000; $i+=10) {
$url = "https://www.google.com/search?q=$dork&start=".$i;
$resp = $ag->request(HTTP::Request->new(GET => $url));
$rrs = $resp->content;




 
while($rrs =~ m/http:\/\/(.*?)\//g){



$link = $1;
	if ( $link !~ /overture|msn|live|bing|yahoo|duckduckgo|google|w3|microsof/)
	{
				if ($link !~ /^http:/)
			 {
				$link = 'http://' . "$link" . '/';
			 }



if($link !~ /\"|\?|\=|index\.php/){
					if  (!  grep (/$link/,@result))
					{
print "$link\n";
open(save, '>>Google-Sites.txt');
    print save "$link\n";
    close(save);
						push(@result,$link);
					}
} 
}
}
}
